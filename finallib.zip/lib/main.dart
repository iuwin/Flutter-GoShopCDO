import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'models/cart_model.dart';
import 'models/favorite_model.dart';
import 'models/product_model.dart';
import 'router.dart' as router;

void main() {
  runApp(MiraiApp());
}

class MiraiApp extends StatelessWidget {
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider.value(
          value: Products(),
        ),
        ChangeNotifierProvider.value(
          value: Favorites(),
        ),
        ChangeNotifierProvider.value(
          value: Carts(),
        ),
        // Provider(create: (context) => ProductModel()),
        // ChangeNotifierProxyProvider<ProductModel, FavoriteModel>(
        //   create: (context) => FavoriteModel(),
        //   update: (context, productModel, favoriteModel) {
        //     favoriteModel.productModel = productModel;
        //     return favoriteModel;
        //   },
        // )
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: ThemeData(fontFamily: 'Nunito'),

        initialRoute: '/loading', //initial sa kay wapay loading screen
        onGenerateRoute: router.generateRoute,
      ),
    );
  }
}
