import 'package:flutter/material.dart';
import 'package:sampleflutter/models/favorite_model.dart';
import 'package:provider/provider.dart';

class Favorite extends StatefulWidget {
  @override
  _FavoriteState createState() => _FavoriteState();
}

class _FavoriteState extends State<Favorite> {
  @override
  Widget build(BuildContext context) {
    final favorite = Provider.of<Favorites>(context);
    return Padding(
      padding: const EdgeInsets.all(5),
      child: CustomScrollView(
        slivers: [
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 15),
            sliver: SliverFixedExtentList(
              itemExtent: 130.0,
              delegate: SliverChildBuilderDelegate(
                (BuildContext context, int index) {
                  return Container(
                    margin: EdgeInsets.only(top: 8),
                    width: double.infinity,
                    height: double.infinity,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(4.0),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey,
                          blurRadius: 2.0,
                          offset: Offset(0, 1),
                        )
                      ],
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Expanded(
                            flex: 2,
                            child: Container(
                              child: Image.asset(favorite.products.values
                                      .toList()[index]
                                      .imagePath
                                  // favoriteModel.items[index].imagePath,
                                  ),
                            ),
                          ),
                          Expanded(
                            flex: 4,
                            child: Container(
                              padding: EdgeInsets.only(left: 10),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.spaceAround,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Expanded(
                                    flex: 2,
                                    child: Container(
                                        alignment: Alignment.centerLeft,
                                        child: Text(favorite.products.values
                                                .toList()[index]
                                                .productName
                                            // favoriteModel.items[index].productName,
                                            )),
                                  ),
                                  Expanded(
                                    flex: 1,
                                    child: Container(
                                        alignment: Alignment.centerLeft,
                                        child: Text(
                                            // favoriteModel.items[index].category
                                            favorite.products.values
                                                .toList()[index]
                                                .category)),
                                  ),
                                  Expanded(
                                    flex: 2,
                                    child: Container(
                                        alignment: Alignment.centerLeft,
                                        child: Text('${favorite.products.values
                                                .toList()[index]
                                                .price}')),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Expanded(
                            flex: 1,
                            child: Container(
                                child: Align(
                                  alignment: Alignment.topRight,
                                  child: Icon(Icons.close, size: 15,),
                                )),
                          ),
                        ],
                      ),
                    ),
                  );
                },
                childCount: favorite.products.length,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// IconButton(
//       icon: Icon(Icons.remove_circle_outline),
//       onPressed: () {
//         favorite.remove(favorite.items[index]);
//       },
//     ),
