import 'package:flutter/material.dart';
import 'router.dart' as router;


void main() => runApp(MaterialApp(
  debugShowCheckedModeBanner: false,
  theme: ThemeData(fontFamily: 'Nunito'),

  initialRoute: '/login',  //initial sa kay wapay loading screen
  onGenerateRoute: router.generateRoute,
  
  // routes: {
  //   '/' :  (context) => LoadingScreen(),
  //   '/home' : (context) => Home(),
  //   '/login' : (context) => Login(),
  //   '/register' : (context) => Register(),

  // },
));



