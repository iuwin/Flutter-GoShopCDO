import 'package:flutter/material.dart';
import 'transaction.dart';

class TransactionBody extends StatefulWidget {
  @override
  _TransactionBody createState() => _TransactionBody();
}

class _TransactionBody extends State<TransactionBody> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(5),
      child: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: Transaction(),
          ),
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 15),
            sliver: SliverFixedExtentList(
              itemExtent: 130.0,
              delegate: SliverChildBuilderDelegate(
                (BuildContext context, int index) {
                  return Container(
                    margin: EdgeInsets.only(top: 8),
                    width: double.infinity,
                    height: double.infinity,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(4.0),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey,
                          blurRadius: 2.0,
                          offset: Offset(0, 1),
                        )
                      ],
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Expanded(
                            flex: 6,
                            child: Container(
                              padding: EdgeInsets.only(left: 10),
                              child: Column(
                                // mainAxisAlignment:
                                //     MainAxisAlignment.spaceAround,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Expanded(
                                    flex: 4,
                                    child: Container(
                                      decoration: BoxDecoration(
                                        // color: Colors.blueGrey[50],
                                        border: Border(
                                          bottom: BorderSide(
                                              width: 1.0,
                                              color: Colors.black54),
                                        ),
                                        // borderRadius:
                                        //     BorderRadius.circular(4.0),
                                      ),
                                      alignment: Alignment.centerLeft,
                                      child: Text(
                                        'Order # : ' + index.toString(),
                                        style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontSize: 22.0),
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    flex: 6,
                                    child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceEvenly,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            width: double.infinity,
                                            child: Text(
                                              '8 January 2021',
                                              style: TextStyle(
                                                fontSize: 10.0,
                                              ),
                                            ),
                                          ),
                                          Container(
                                            alignment: Alignment.centerLeft,
                                            child: Row(
                                              children: [
                                                Text('Payment Status: '),
                                                Container(
                                                  padding: EdgeInsets.fromLTRB(
                                                      8, 7, 8, 7),
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            4.0),
                                                    color: (index > 0)
                                                        ? Color(0XFFe5f7eb)
                                                        : Color(0XFFfdf1f3),
                                                    border: Border.all(
                                                      style: BorderStyle.none,
                                                    ),
                                                  ),
                                                  child: Text(
                                                    (index > 0)
                                                        ? 'Completed'
                                                        : 'Error',
                                                    style: TextStyle(
                                                      fontSize: 11.0,
                                                      color: (index > 0)
                                                          ? Color(0XFF3EC064)
                                                          : Color(0XFFe9ab9b),
                                                      // backgroundColor:
                                                      //     Color(0XFFe5f7eb),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                            // Color(0xFFB308278),
                                          )
                                        ]),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Expanded(
                            flex: 4,
                            child: GestureDetector(
                              onTap: () => Navigator.pushNamed(
                                  context, '/viewtransaction'),
                              child: Container(
                                margin: EdgeInsets.only(right: 25, left: 25),
                                padding: EdgeInsets.fromLTRB(8, 7, 8, 7),
                                child: Text(
                                  'View',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold),
                                ),
                                decoration: BoxDecoration(
                                    color: Color(0xFFB296961),
                                    borderRadius: BorderRadius.circular(5)),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
                childCount: 2,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
