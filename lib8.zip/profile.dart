import 'package:flutter/material.dart';
import 'package:sampleflutter/custom_widget/posted_products.dart';
import 'package:sampleflutter/custom_widget/profile_picture.dart';
import 'package:sampleflutter/custom_widget/transaction_body.dart';
import 'package:sampleflutter/custom_widget/trend_tab_bar_widget.dart';
import 'package:sampleflutter/custom_widget/favorite.dart';

class Profile extends StatefulWidget {
  _StateProfile createState() => _StateProfile();
}

class _StateProfile extends State<Profile> with SingleTickerProviderStateMixin {
  final List<String> _tabs = ['Transaction', 'Favorites', 'Posted'];

  TabController? _tabController;
  ScrollController? _scrollController;

  @override
  void initState() {
    super.initState();
    _tabController = new TabController(length: _tabs.length, vsync: this);
    _scrollController = new ScrollController();
  }

  @override
  void dispose() {
    _tabController!.dispose();
    _scrollController!.dispose();
    super.dispose();
  }

  // Start of the user Profile Section Compose of profile, info, ratings..
  Widget _userProfile(List<String> _tabs, TabController _tabController) {
    return Stack(children: <Widget>[
      Container(
        width: MediaQuery.of(context).size.width * 1,
        height: MediaQuery.of(context).size.height * .20,
        decoration: BoxDecoration(
          color: Colors.black12,
        ),
        // bar for settings, help .....

        child: CustomScrollView(slivers: [
          SliverSafeArea(
            sliver: SliverAppBar(
              automaticallyImplyLeading: false,
              // title: Icon(Icons.filter_list, color: Colors.black),
              pinned: false,
              floating: false,
              snap: false,
              // elevation: 0,
              actions: [
                // IconButton(
                //   icon: Icon(
                //     Icons.search,
                //     color: Colors.black,
                //     size: 30,
                //   ),
                //   onPressed: () {
                //     Navigator.pushNamed(context, '/search');
                //     // showSearch(context: context, delegate: Search());
                //   },
                // ),
              ],
              backgroundColor: Colors.white,
              flexibleSpace: FlexibleSpaceBar(
                  collapseMode: CollapseMode.pin,
                  background: Container(
                    color: Color(0xFFB308278),
                  ) //TitleWidget(title: 'Profile'),
                  ),
              expandedHeight: MediaQuery.of(context).size.height * .20,
            ),
          ),
        ]),
      ),
      _profileImage(),
      Positioned(
        top: 60,
        left: 90,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Pepeng Kaliwite',
              style: TextStyle(
                  color: Colors.grey[100],
                  fontSize: 18,
                  fontWeight: FontWeight.bold),
            ),
            SizedBox(
              height: 2,
            ),
            Text(
              'Product Posted: 0',
              style: TextStyle(
                  color: Colors.grey[400],
                  fontSize: 12,
                  fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
      Positioned(
        top: 8,
        right: 20,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            IconButton(
              onPressed: () {},
              icon: Icon(Icons.settings),
              color: Colors.white70,
            ),
            // ignore: deprecated_member_use
            Stack(overflow: Overflow.visible, children: [
              IconButton(
                onPressed: () {},
                icon: Icon(Icons.chat_bubble),
                color: Colors.white70,
              ),
              Positioned(
                top: 0,
                right: 5,
                child: Container(
                  padding: EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                  decoration: BoxDecoration(
                      color: Colors.red[400],
                      borderRadius: BorderRadius.circular(15)),
                  child: Text(
                    '2',
                    style: TextStyle(
                        color: Colors.white70,
                        fontSize: 10,
                        fontWeight: FontWeight.bold),
                  ),
                ),
              )
            ]),
          ],
        ),
      ),
    ]);
  }

  // Widget for profile picture
  Widget _profileImage() {
    return Positioned(
      left: 15,
      top: 50,
      child: ProfilePicture(),
    );
  }

  // transaction
  Widget _defaultTabControllerWidget(context) {
    return NestedScrollView(
        controller: _scrollController,
        // ensure that the app bar shows a shadow
        headerSliverBuilder: (BuildContext context, bool innerBoxIsScrolled) {
          // These are the slivers that show up in the "outer" scroll view.
          return <Widget>[
            // create a sliver that absorb the overlap and report to the sliveroverlapabsorvhandle
            SliverSafeArea(
              sliver: SliverToBoxAdapter(
                child: _userProfile(_tabs, _tabController!),
              ),
            ),
          ];
        },
        body: SingleChildScrollView(
          child: Column(
            children: [
              TrendTabBar(tabs: this._tabs, tabController: this._tabController),
              Container(
                height: MediaQuery.of(context).size.height,
                child: TabBarView(
                  children: [TransactionBody(), Favorite(), PostedProduct()],
                  controller: _tabController,
                ),
              ),
            ],
          ),
        ));
  }

  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: _defaultTabControllerWidget(context),
      ),
    );
  }
}
