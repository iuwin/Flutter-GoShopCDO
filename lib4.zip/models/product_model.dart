import 'package:flutter/foundation.dart';

class ProductModel with ChangeNotifier {
  final int id;
  final String imagePath;
  final String productName;
  final String category;
  // final price;

  ProductModel({
    @required this.id,
    @required this.imagePath,
    @required this.productName,
    @required this.category,
    // @required this.price,
  });
}

class Products with ChangeNotifier {
  List<ProductModel> _products = [
    //Clothing
    ProductModel(
        id: 1,
        imagePath: 'assets/products/clothing/girl_jacket.png',
        productName: 'Women\'s Jacket',
        category: 'clothing'),
    ProductModel(
        id: 2,
        imagePath: 'assets/products/clothing/cap.png',
        productName: 'Nike Cap',
        category: 'clothing'),
    ProductModel(
        id: 3,
        imagePath: 'assets/products/clothing/boy_jacket.png',
        productName: 'Men\'s Jacket',
        category: 'clothing'),
    ProductModel(
        id: 4,
        imagePath: 'assets/products/clothing/jeans.png',
        productName: 'Jeans',
        category: 'clothing'),
    ProductModel(
        id: 5,
        imagePath: 'assets/products/clothing/jordan_shoes.png',
        productName: 'Jordan Shoes',
        category: 'clothing'),

    //Gadgets
    ProductModel(
        id: 6,
        imagePath: 'assets/products/gadgets/laptop.png',
        productName: 'HP Laptop',
        category: 'gadgets'),
    ProductModel(
        id: 7,
        imagePath: 'assets/products/gadgets/mouse.png',
        productName: 'Wired Mouse',
        category: 'gadgets'),
    ProductModel(
        id: 8,
        imagePath: 'assets/products/gadgets/keyboard.png',
        productName: 'Keyboard',
        category: 'gadgets'),
    ProductModel(
        id: 9,
        imagePath: 'assets/products/gadgets/flashdrive.png',
        productName: 'Flashdrive',
        category: 'gadgets'),
    ProductModel(
        id: 10,
        imagePath: 'assets/products/gadgets/wireless_camera.png',
        productName: 'Wireless Camera',
        category: 'gadgets'),

    //Furnitures
    ProductModel(
        id: 11,
        imagePath: 'assets/products/furniture/sofa.png',
        productName: 'Sofa',
        category: 'furniture'),
    ProductModel(
        id: 12,
        imagePath: 'assets/products/furniture/chair.png',
        productName: 'Wooden Chair',
        category: 'furniture'),
    ProductModel(
        id: 13,
        imagePath: 'assets/products/furniture/bed.png',
        productName: 'Bed',
        category: 'furniture'),
    ProductModel(
        id: 14,
        imagePath: 'assets/products/furniture/table.png',
        productName: 'Table',
        category: 'furniture'),
    ProductModel(
        id: 15,
        imagePath: 'assets/products/furniture/umbrella_holder.png',
        productName: 'Umbrella Holder',
        category: 'furniture'),

    //Toys
    ProductModel(
        id: 16,
        imagePath: 'assets/products/toys/stuff_toy.png',
        productName: 'Stuff Toy',
        category: 'toy'),
    ProductModel(
        id: 17,
        imagePath: 'assets/products/toys/doll_house.png',
        productName: 'Doll House',
        category: 'toy'),
    ProductModel(
        id: 18,
        imagePath: 'assets/products/toys/cow_piano.png',
        productName: 'Cow Piano',
        category: 'toy'),
    ProductModel(
        id: 19,
        imagePath: 'assets/products/toys/robot.png',
        productName: 'Robot',
        category: 'toy'),
    ProductModel(
        id: 20,
        imagePath: 'assets/products/toys/toy_gun.png',
        productName: 'Toy Gun',
        category: 'toy'),

    //Hardware

    ProductModel(
        id: 21,
        imagePath: 'assets/products/hardware/hammer.png',
        productName: 'Hammer',
        category: 'hardware'),
    ProductModel(
        id: 22,
        imagePath: 'assets/products/hardware/tool_case.png',
        productName: 'Tool Case',
        category: 'hardware'),
    ProductModel(
        id: 23,
        imagePath: 'assets/products/hardware/doorknob.png',
        productName: 'Door knob',
        category: 'hardware'),
    ProductModel(
        id: 24,
        imagePath: 'assets/products/hardware/plier.png',
        productName: 'Lineman\'s Plier',
        category: 'hardware'),
  ];

  List<ProductModel> get products => [..._products];
}
