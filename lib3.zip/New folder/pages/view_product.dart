import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:sampleflutter/distance_calculator.dart';
import 'dart:ui' as ui;


class ProductView extends StatefulWidget {
  Map productDetails = new Map();

  ProductView({this.productDetails});
  @override
  _ProductViewState createState() => _ProductViewState();
}
    
class _ProductViewState extends State<ProductView> {

  GoogleMapController _mapController;
  final CameraPosition _initialCameraPosition = CameraPosition(target: LatLng(8.476629, 124.6390383), zoom: 13);
  
  ///Buyer/User Location (diri ibutang ang coordinates sa buyer)
  LatLng _userLocation = LatLng(8.4676022,124.62209969999999); //DUMMY

  ///Seller Location (diri ibutang ang coordinates sa seller)
  LatLng _sellerLocation = LatLng(8.476629, 124.6390383); //DUMMY
  
  ///Seller and Buyer Distance
  double _sellerBuyerDistance = 0;
  int _distanceKM = 0;
  int _distanceMeter = 0;

  ///Marker
  List<Marker> _mapMarkers = [];
  Uint8List _userMarkerImage;
  Uint8List _sellerMarkerImage;
 
  @override
  void initState()  { 
    super.initState();
    Distance distance = new Distance(userLatitude: _userLocation.latitude, userLongitude: _userLocation.longitude,
                                    sellerLatitude: _sellerLocation.latitude, sellerLongitude: _sellerLocation.longitude);
    
    _sellerBuyerDistance = distance.getDistanceFromLatLonInKm();
    _distanceKM = _sellerBuyerDistance.toInt();
    _distanceMeter = _distanceKM * 1000;
    print('$_distanceKM KM');
    print('$_distanceMeter M');

    _assignIcon();
  }   

  ///Marker Image Renderer
  Future<Uint8List> getBytesFromAsset(String path, int width) async {
    ByteData data = await rootBundle.load(path);
    ui.Codec codec = await ui.instantiateImageCodec(data.buffer.asUint8List(), targetWidth: width);
    ui.FrameInfo fi = await codec.getNextFrame();
    return (await fi.image.toByteData(format: ui.ImageByteFormat.png)).buffer.asUint8List();
  }
  
  void _assignIcon() async {
    _userMarkerImage = await getBytesFromAsset('assets/icons/user-marker.png', 70);
    _sellerMarkerImage = await getBytesFromAsset('assets/icons/seller-marker.png', 70);
  } 
  
  ///Text Generator
  Widget _textGenerator(
          {String text, Color color, double fontSize, FontWeight fontWeight}) =>
      Container(
        padding: EdgeInsets.fromLTRB(25, 15, 25, 0),
        child: Text(
          text,
          style: TextStyle(
              fontSize: fontSize, color: color, fontWeight: fontWeight),
          textAlign: TextAlign.justify,
        ),
      );

  ///Color Variation (Optional)
  Widget _colorVariationGenerator({Color color}) => CircleAvatar(
        backgroundColor: color,
        radius: 15,
      );

  ///Upper Radius Effect (PNG only)
  Widget _upperBorderRadius() => SliverToBoxAdapter(
        child: Container(
          color: Color(0xFFB308278),
          height: 20,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Container(
                height: 20,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                    topLeft: const Radius.circular(40.0),
                    topRight: const Radius.circular(40.0),
                  ),
                ),
              ),
            ],
          ),
        ),
      );

  ///Underline Widget
  Widget _underlineUI(double width) => Align(
    alignment: Alignment.centerLeft,
    child: Container(
      height: 3,
      width: width,
      margin: EdgeInsets.only(left: 25),
      decoration: BoxDecoration(
        color: Color(0xFFB308278),
        borderRadius: BorderRadius.circular(25)
      ),
      child: Text(' '),
    ),
  );

  ///Build
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            //title: addtocart button here,
            backgroundColor: Color(0xFFB308278),
            expandedHeight: 200,
            flexibleSpace: FlexibleSpaceBar(
              background: Image.asset(
                widget.productDetails['imagePath'], //PRODUCT IMAGE
                fit: BoxFit.contain,
              ),
            ),
          ),
          _upperBorderRadius(),
          SliverList(
            delegate: SliverChildListDelegate([
              //Product Name
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  _textGenerator(
                      text: widget.productDetails['productName'], //PRODUCT NAME
                      color: Colors.black,
                      fontSize: 20,
                      fontWeight: FontWeight.bold),
                  Padding(
                    padding: EdgeInsets.only(right: 20),
                    child: Icon(Icons.favorite_border),
                  ),
                ],
              ),
              //Price
              _textGenerator(
                  text: 'P5,000',
                  color: Colors.black,
                  fontSize: 20,
                  fontWeight: FontWeight.bold),
              SizedBox(height: 20),
              //Description
              _textGenerator(
                  text: 'Details',
                  color: Colors.black,
                  fontSize: 16,
                  fontWeight: FontWeight.bold),
              SizedBox(height: 1),
              _underlineUI(55),
              SizedBox(height: 5),
              _textGenerator(
                text:
                    'The new iphone provides users the best technologies from apple. It is slick and have a variety of colors to choose from. Bill Gates said i love you.',
                color: Colors.grey[600],
                fontSize: 14,
                fontWeight: FontWeight.normal,
              ),
              SizedBox(height: 20),
              //Color Variation
               _textGenerator(
                  text: 'Colors',
                  color: Colors.black,
                  fontSize: 16,
                  fontWeight: FontWeight.bold
                ),
              SizedBox(height: 1),
              _underlineUI(51),
              SizedBox(height: 25),
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  SizedBox(width: 25),
                  _colorVariationGenerator(color: Colors.blue),
                  SizedBox(width: 15),
                  _colorVariationGenerator(color: Colors.black),
                  SizedBox(width: 15),
                  _colorVariationGenerator(color: Colors.amber[600]),
                  SizedBox(width: 15),
                  _colorVariationGenerator(color: Colors.grey),
                  SizedBox(width: 15),
                ],
              ),
              SizedBox(
                height: 20,
              ),
              Container(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _textGenerator(
                      text: 'Map',
                      color: Colors.black,
                      fontSize: 16,
                      fontWeight: FontWeight.bold
                    ),
                    SizedBox(height: 1),
                    _underlineUI(35),
                    SizedBox(
                      height: 25,
                    ),
                    Container(
                      height: 200,
                      decoration: BoxDecoration(
                        border: Border.all(
                          color: Colors.grey[300]
                        )
                      ),
                      margin: EdgeInsets.symmetric(horizontal: 25),
                      child: GoogleMap(
                        initialCameraPosition: _initialCameraPosition,
                        mapType: MapType.terrain,
                        markers: _mapMarkers.toSet(),
                        onMapCreated: (controller){
                          setState((){
                            String sellerMarkerId = '0';
                            String buyerMarkerId = '1';

                            _mapController = controller;
                            _mapMarkers.add(Marker(icon: BitmapDescriptor.fromBytes(_sellerMarkerImage), position: _sellerLocation, markerId: MarkerId(sellerMarkerId)));
                            _mapMarkers.add(Marker(icon: BitmapDescriptor.fromBytes(_userMarkerImage), position: _userLocation, markerId: MarkerId(buyerMarkerId)));
                          });
                        },
                        onTap: (coordinate){
                          _mapController.animateCamera(CameraUpdate.newLatLng(coordinate));
                        },
                      ),
                    ),
                    SizedBox(height: 5),
                    Center(
                      child: _textGenerator(
                        text: 'Distance: $_distanceKM Kilometers / $_distanceMeter Meters',
                        color: Colors.grey[600],
                        fontSize: 14,
                        fontWeight: FontWeight.normal
                      ),
                    ),
                  ],
                )   
              ),
              SizedBox(height: 25),
              _textGenerator(
                text: 'Reviews',
                color: Colors.black,
                fontSize: 16,
                fontWeight: FontWeight.bold
              ),
              SizedBox(height: 1),
              _underlineUI(65),
              SizedBox(
                height: 25,
              ),
              Container(
                child: Column(
                  children: [
                    
                  ],
                ),
              ),
              SizedBox(
                height: 100
              )
            ]),
          ),
        ],
      ),
      bottomNavigationBar:
          Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
        Container(
          margin: EdgeInsets.only(bottom: 10, top: 5),
          padding: EdgeInsets.fromLTRB(75, 12, 75, 12),
          child: Text(
            'Buy now',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
          ),
          decoration: BoxDecoration(
              color: Color(0xFFB296961),
              borderRadius: BorderRadius.circular(5)),
        ),
        Container(
          margin: EdgeInsets.only(bottom: 10, top: 5),
          padding: EdgeInsets.fromLTRB(30, 12, 30, 12),
          child: Text('Add to Cart',
              textAlign: TextAlign.center,
              style:
                  TextStyle(color: Color(0xFFB296961), fontWeight: FontWeight.bold)),
          decoration: BoxDecoration(
              border: Border.all(
                color: Color(0xFFB296961),
              ),
              //color: Color(0xFFB296961),
              borderRadius: BorderRadius.circular(5)),
        )
      ]),
    );
  }
}
