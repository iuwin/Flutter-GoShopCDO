import 'package:flutter/material.dart';
import 'package:sampleflutter/models/favorite_model.dart';
import 'package:provider/provider.dart';

class Favorite extends StatefulWidget {
  @override
  _FavoriteState createState() => _FavoriteState();
}

class _FavoriteState extends State<Favorite> {
  @override
  Widget build(BuildContext context) {
    final favorite = Provider.of<Favorites>(context);
    return CustomScrollView(
      slivers: [
        SliverPadding(
          padding: const EdgeInsets.all(8.0),
          sliver: SliverFixedExtentList(
            itemExtent: 130.0,
            delegate: SliverChildBuilderDelegate(
              (BuildContext context, int index) {
                return Container(
                  margin: EdgeInsets.only(top: 8),
                  width: double.infinity,
                  height: double.infinity,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(4.0),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey,
                        blurRadius: 2.0,
                        offset: Offset(0, 1),
                      )
                    ],
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Expanded(
                          flex: 2,
                          child: Container(
                            decoration: BoxDecoration(
                                border: Border.all(color: Colors.blue)),
                            child: Image.asset(favorite.products.values
                                    .toList()[index]
                                    .imagePath
                                // favoriteModel.items[index].imagePath,
                                ),
                          ),
                        ),
                        Expanded(
                          flex: 4,
                          child: Container(
                            padding: EdgeInsets.only(left: 10),
                            decoration: BoxDecoration(
                                border: Border.all(color: Colors.blue)),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Expanded(
                                  flex: 2,
                                  child: Container(
                                      alignment: Alignment.centerLeft,
                                      child: Text(favorite.products.values
                                              .toList()[index]
                                              .productName
                                          // favoriteModel.items[index].productName,
                                          )),
                                ),
                                Expanded(
                                  flex: 1,
                                  child: Container(
                                      alignment: Alignment.centerLeft,
                                      child: Text(
                                          // favoriteModel.items[index].category
                                          favorite.products.values
                                              .toList()[index]
                                              .category)),
                                ),
                                Expanded(
                                  flex: 2,
                                  child: Container(
                                      alignment: Alignment.centerLeft,
                                      child: Text('price')),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Expanded(
                          flex: 1,
                          child: Container(
                              decoration: BoxDecoration(
                                  border: Border.all(color: Colors.blue)),
                              child: Align(
                                alignment: Alignment.topRight,
                                child: Icon(Icons.close_outlined),
                              )),
                        ),
                      ],
                    ),
                  ),
                );
              },
              childCount: favorite.products.length,
            ),
          ),
        ),
      ],
    );
  }
}

// IconButton(
//       icon: Icon(Icons.remove_circle_outline),
//       onPressed: () {
//         favorite.remove(favorite.items[index]);
//       },
//     ),
