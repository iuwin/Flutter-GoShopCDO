import 'package:flutter/material.dart';

class CustomTextFormField extends StatefulWidget {
  String hintTextType;
  TextEditingController textEditingController;
  Icon fieldIcon;
  int maxLine;
  double height;
  TextInputType inputType;

  CustomTextFormField(
      {this.height = 50,
      this.maxLine = 1,
      this.inputType = TextInputType.text,
      @required this.hintTextType,
      @required this.textEditingController,
      @required this.fieldIcon});

  // String valueType;
  CustomTextFormFieldState createState() => CustomTextFormFieldState();
}

class CustomTextFormFieldState extends State<CustomTextFormField> {
  Widget build(BuildContext context) {
    return Theme(
      child: Container(
        height: widget.height,
        child: TextFormField(
          validator: (String value) {
            {
              if (widget.hintTextType == 'Product Name') {
                if (value.isEmpty) {
                  return widget.hintTextType + ' is Required';
                }
              } else if (widget.hintTextType == 'Category') {
                if (value.isEmpty) {
                  return widget.hintTextType + ' is Required';
                }
              } else if (widget.hintTextType == 'Description') {
                if (value.isEmpty) {
                  return widget.hintTextType + ' is Required';
                }
              } else if (widget.hintTextType == 'Condition') {
                if (value.isEmpty) {
                  return widget.hintTextType + ' is Required';
                }
              } else if (widget.hintTextType == 'Fixed Price') {
                if (value.isEmpty) {
                  return widget.hintTextType + ' is Required';
                }
              } else if (widget.hintTextType == 'Bargain Price') {
                if (value.isEmpty) {
                  return widget.hintTextType + ' is Required';
                }
              } else if (widget.hintTextType == 'Address') {
                if (value.isEmpty) {
                  return widget.hintTextType + ' is Required';
                }
              } else if (widget.hintTextType == 'Stock Quantity') {
                if (value.isEmpty) {
                  return widget.hintTextType + ' is Required';
                }
              }

              return null;
            }
          },
          controller: widget.textEditingController,
          maxLines: widget.maxLine,
          keyboardType: widget.inputType,
          decoration: InputDecoration(
            prefixIcon: widget.fieldIcon,
            hintText: widget.hintTextType,
            errorStyle: TextStyle(),
            enabledBorder: UnderlineInputBorder(
              borderSide: BorderSide(
                color: Colors.grey[200],
                width: 2,
              ),
            ),
            focusedBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: Colors.grey[200], width: 2),
            ),
          ),
        ),
      ),
      data: Theme.of(context).copyWith(primaryColor: Color(0xFFB296961)),
    );
  }
}
