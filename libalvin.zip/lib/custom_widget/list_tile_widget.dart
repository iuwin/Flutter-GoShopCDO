import 'package:flutter/material.dart';

class ListTileTemplate extends StatefulWidget {
  BuildContext context;
  ListTileTemplate({@required this.context});

  @override
  _ListTileTemplateState createState() => _ListTileTemplateState();
}

class _ListTileTemplateState extends State<ListTileTemplate> {
  Widget build(BuildContext context) {
    return CustomScrollView(
      slivers: [
        SliverPadding(
          padding: const EdgeInsets.all(8.0),
          sliver: SliverFixedExtentList(
            itemExtent: 48.0,
            delegate: SliverChildBuilderDelegate(
              (BuildContext context, int index) {
                return Card(
                  child: ListTile(
                    title: Text('Item $index'),
                  ),
                );
              },
              childCount: 30,
            ),
          ),
        ),
      ],
    );
  }
}
