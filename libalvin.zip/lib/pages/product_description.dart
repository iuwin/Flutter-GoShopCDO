// import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:sampleflutter/custom_widget/custom_text_form_field_widget.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io' as Io;
import 'dart:convert';

class ProductDescription extends StatefulWidget {
  ProductDescriptionState createState() => ProductDescriptionState();
}

class ProductDescriptionState extends State<ProductDescription> {
  static final formKey = GlobalKey<FormState>();
  static TextEditingController productNameController =
      new TextEditingController();
  static TextEditingController categoryController = new TextEditingController();
  static TextEditingController descriptionController =
      new TextEditingController();
  static TextEditingController addressController = new TextEditingController();
  static String selectedCategory;
  static String selectedCondition;
  static Io.File productPhotoFile;
  static List<int> bytes;
  static String img64;

  List<String> _category = [
    'Clothing',
    'Gadgets',
    'Furnitures',
    'Toys',
    'Hardware'
  ];

  List<String> _condition = ['Brand New', 'Used'];

  Widget build(BuildContext context) {
    selectFromCamera() async {
      // ignore: deprecated_member_use
      productPhotoFile = (await ImagePicker.pickImage(
        source: ImageSource.camera,
        maxHeight: 300.0,
        maxWidth: 300.0,
      ));

      setState(() {
        bytes = productPhotoFile.readAsBytesSync();
        img64 = base64Encode(bytes);
      });
      print('Converted: ' + img64);
    }

    return Container(
      child: Form(
        key: formKey,
        child: Column(
          children: [
            new Center(
              child: productPhotoFile == null
                  ? GestureDetector(
                      onTap: selectFromCamera,
                      child: Icon(
                        Icons.add_a_photo,
                        size: 50.0,
                      ),
                    )
                  : Column(children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: Image.file(productPhotoFile),
                      ),
                      GestureDetector(
                        onTap: selectFromCamera,
                        child: Icon(
                          Icons.add_a_photo,
                          size: 50.0,
                        ),
                      )
                    ]),
            ),
            SizedBox(height: 30.0),
            new CustomTextFormField(
              hintTextType: 'Product Name',
              textEditingController: productNameController,
              fieldIcon: null,
            ),
            SizedBox(height: 30.0),
            new CustomTextFormField(
              hintTextType: 'Description',
              textEditingController: descriptionController,
              height: 100,
              maxLine: 8,
              inputType: TextInputType.multiline,
              fieldIcon: null,
            ),
            SizedBox(height: 30.0),
            new DropdownButtonFormField<String>(
              value: (selectedCategory == null) ? null : selectedCategory,
              hint: Text('Category'),
              icon: Icon(Icons.format_list_bulleted),
              validator: (String value) {
                if (value == null) {
                  return 'Category is Required';
                }
                return null;
              },
              items: _category
                  .map(
                    (c) => DropdownMenuItem(
                      child: Text(c),
                      value: c,
                    ),
                  )
                  .toList(),
              onChanged: (value) {
                setState(() {
                  selectedCategory = value;
                });
              },
              decoration: InputDecoration(
                enabledBorder: UnderlineInputBorder(
                  borderSide: BorderSide(
                    color: Colors.grey[200],
                    width: 2,
                  ),
                ),
                focusedBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Colors.grey[200], width: 2),
                ),
              ),
            ),
            SizedBox(height: 30.0),
            new CustomTextFormField(
              hintTextType: 'Address',
              textEditingController: addressController,
              fieldIcon: new Icon(Icons.location_on),
            ),
            SizedBox(height: 30.0),
            new DropdownButtonFormField<String>(
              value: (selectedCondition == null) ? null : selectedCondition,
              hint: Text('Condition'),
              icon: Icon(Icons.sentiment_satisfied),
              validator: (String value) {
                if (value == null) {
                  return 'Condition is Required';
                }
                return null;
              },
              items: _condition
                  .map(
                    (c) => DropdownMenuItem(
                      child: Text(c),
                      value: c,
                    ),
                  )
                  .toList(),
              onChanged: (value) {
                setState(() {
                  selectedCondition = value;
                });
              },
              decoration: InputDecoration(
                enabledBorder: UnderlineInputBorder(
                  borderSide: BorderSide(
                    color: Colors.grey[200],
                    width: 2,
                  ),
                ),
                focusedBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Colors.grey[200], width: 2),
                ),
              ),
            ),
            SizedBox(height: 30.0),
          ],
        ),
      ),
    );
  }
}
