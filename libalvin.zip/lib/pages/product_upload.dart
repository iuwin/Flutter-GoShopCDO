import 'dart:collection';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'dart:io' as Io;
import 'dart:convert';

class ProductUpload extends StatefulWidget {
  var mapInfo = HashMap<String, String>();

  ProductUpload({@required this.mapInfo});

  _ProductUploadState createState() => _ProductUploadState();
}

class _ProductUploadState extends State<ProductUpload> {
  Widget generateRow(String label, String value) => Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Text(
            label,
            style: TextStyle(
              fontSize: 14,
            ),
          ),
          Text(
            value,
            style: TextStyle(
              fontSize: 14,
            ),
          )
        ],
      );

  Widget build(BuildContext context) {
    var productPhotoConvertedToString =
        widget.mapInfo["productPhotoConvertedToString"];
    var productName = widget.mapInfo["productName"];
    var category = widget.mapInfo["category"];
    var description = widget.mapInfo["description"];
    var condition = widget.mapInfo["condition"];
    var address = widget.mapInfo["address"];
    var fixedPrice = widget.mapInfo["fixedPrice"];
    var bargainPrice = widget.mapInfo["bargainPrice"];
    var quantity = widget.mapInfo["quantity"];
    final Uint8List decodedBytes = base64Decode(productPhotoConvertedToString);
    // Io.File tempFile = Io.File('tempFile.png');
    // tempFile.writeAsBytesSync(decodedBytes);
    // TODO: implement build
    return Container(
      child: SingleChildScrollView(
        child: Column(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: Image.memory(decodedBytes),
            ),
            generateRow('Title :', productName),
            generateRow('Category :', category),
            generateRow('Description :', description),
            generateRow('Condition :', condition),
            generateRow('Address :', address),
            generateRow('Fixed Price :', fixedPrice),
            generateRow('Bargain Price :', bargainPrice),
            generateRow('Quantity :', quantity),
          ],
        ),
      ),
    );
  }
}
