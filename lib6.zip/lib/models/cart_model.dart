import 'package:flutter/foundation.dart';

class CartModel {
  final String id;
  final String imagePath;
  final String productName;
  final String category;
  final String price;
  // final price;

  CartModel({
    this.id,
    @required this.imagePath,
    @required this.productName,
    this.category,
    this.price
    // @required this.price,
  });
}

class Carts with ChangeNotifier {
  Map<String, CartModel> _products = {};

  Map<String, CartModel> get products => {..._products};

  int get productCount => _products.length;

  void addCartProduct(String cartProductId, String cartImagePath,
      String cartProductName, String cartProductCategory, String cartPrice) {
    // check if there are existing product in the Cart list update or add new
    if (_products.containsKey(cartProductId)) {
      _products.update(
          cartProductId,
          (existingCartProduct) => CartModel(
              id: DateTime.now().toString(),
              price: existingCartProduct.price,
              imagePath: existingCartProduct.imagePath,
              productName: existingCartProduct.productName,
              category: existingCartProduct.category));
    } else {
      _products.putIfAbsent(
          cartProductId,
          () => CartModel(
              id: DateTime.now().toString(),
              price: cartPrice,
              imagePath: cartImagePath,
              productName: cartProductName,
              category: cartProductCategory));
    }
    notifyListeners();
  }

  void removeProduct(String id) {
    _products.remove(id);
    notifyListeners();
  }

  // void removeSingleProduct(String id) {
  //   if (_products.containsKey(id)) {
  //     return;
  //   }
  //   if (_products[id].quanity > 1) {
  //     _products.update(id, (existingCartProduct) => CartModel(
  //             id: DateTime.now().toString(),
  //             imagePath: existingCartProduct.imagePath,
  //             quantity: existingCartProduct.quantity - 1,
  //             productName: existingCartProduct.productName,
  //             category: existingCartProduct.category));
  //   }
  // notifyListeners();
  // }

  void clear() {
    _products = {};
    notifyListeners();
  }
}
