import'dart:math' as Math;

class Distance{
  double userLatitude, userLongitude;
  double sellerLatitude, sellerLongitude;
  double distance;

  Distance({this.userLatitude, this.userLongitude,
            this.sellerLatitude, this.sellerLongitude,
          });

  double getDistanceFromLatLonInKm() {
    var earthRadius = 6371; // Radius of the earth in KM
    var latDistance = getRadius(sellerLatitude - userLatitude);
    var longDistance = getRadius(sellerLongitude - userLongitude); 
    var a = 
      Math.sin(latDistance/2) * Math.sin(latDistance/2) +
      Math.cos(getRadius(userLatitude)) * Math.cos(getRadius(sellerLatitude)) * 
      Math.sin(longDistance/2) * Math.sin(longDistance/2); 
    var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
    distance = earthRadius * c; //KM
    return distance;
  }

  double getRadius(deg) {
    return deg * (Math.pi/180);
  }
}