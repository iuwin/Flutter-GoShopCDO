import 'dart:collection';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'dart:io' as Io;
import 'dart:convert';

import 'package:geocoder/geocoder.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class ProductUpload extends StatefulWidget {
  var mapInfo = HashMap<String, String>();

  ProductUpload({this.mapInfo});

  _ProductUploadState createState() => _ProductUploadState();
}

class _ProductUploadState extends State<ProductUpload> {
  //Adresss
  Address _addressDetails;
  LatLng _dummyCoordinates = LatLng(8.476629, 124.6390383);
  
  void getCoordinates(String address) async{
    try {
      final query = address;//"1600 Amphiteatre Parkway, Mountain View";
      var addresses = await Geocoder.local.findAddressesFromQuery(query);
      _addressDetails = addresses.first;
      print("${_addressDetails.featureName} : ${_addressDetails.coordinates}");
    } on Exception catch (error) {
        print(error); //BUTANGAG POP UP NA ERROR PARA MA NOTICE SA USER 
    }
  }

  Widget generateRow(String label, String value) => Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Text(
            label,
            style: TextStyle(
              fontSize: 14,
            ),
          ),
          Text(
            value,
            style: TextStyle(
              fontSize: 14,
            ),
          )
        ],
      );

  Widget build(BuildContext context) {
    var productPhotoConvertedToString =  widget.mapInfo["productPhotoConvertedToString"];
    var productName = widget.mapInfo["productName"];
    var category = widget.mapInfo["category"];
    var description = widget.mapInfo["description"];
    var condition = widget.mapInfo["condition"];
    var fixedPrice = widget.mapInfo["fixedPrice"];
    var bargainPrice = widget.mapInfo["bargainPrice"];
    var quantity = widget.mapInfo["quantity"];
    var address = widget.mapInfo["address"];
    final Uint8List decodedBytes = base64Decode(productPhotoConvertedToString);
    // Io.File tempFile = Io.File('tempFile.png');
    // tempFile.writeAsBytesSync(decodedBytes);
    // TODO: implement build

    getCoordinates(address); //KUHAON ANG COORDINATES SA ADDRESS
    
    return Container(
      child: SingleChildScrollView(
        child: Column(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: Image.memory(decodedBytes),
            ),
            generateRow('Title :', productName),
            generateRow('Category :', category),
            generateRow('Description :', description),
            generateRow('Condition :', condition),
            generateRow('Address :', address),
            generateRow('Fixed Price :', fixedPrice),
            generateRow('Bargain Price :', bargainPrice),
            generateRow('Quantity :', quantity),
          ],
        ),
      ),
    );
  }
}
