import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:provider/provider.dart';
import 'package:sampleflutter/models/product_model.dart';
import 'package:sampleflutter/product.dart';
import 'package:sampleflutter/custom_widget/trend_search_product_template_widget.dart';

class SearchResult extends StatefulWidget {
  @override
  _SearchResultState createState() => _SearchResultState();
}

class _SearchResultState extends State<SearchResult> {
  List<Product> products;

  ///Search Filters
  String _selectedFilter = 'Best match';
  List<String> _filters = ['Best match', 'Price', 'Location'];
  
  @override
  void initState() {
    super.initState();
    //products = initProducts();
  }

  Widget _searchBar() => Container(
        height: 60, //MediaQuery.of(context).size.height * .15,
        decoration: BoxDecoration(
          color: Color(0xFFB308278), //Colors.grey[200],
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            IconButton(
              icon: Icon(Icons.arrow_back, size: 20),
              color: Colors.white,
              onPressed: () {
                Navigator.pushNamed(context, '/home');
              },
            ),
            Container(
              height: 35,
              width: MediaQuery.of(context).size.width * .73,
              child: TextFormField(
                  onTap: () {
                    Navigator.pushNamed(context, '/search');
                  },
                  decoration: InputDecoration(
                    hintText: 'Search product',
                    // suffixIcon: IconButton(
                    //   onPressed: (){},
                    //   icon: Icon(Icons.clear, size: 20),
                    //   color: Colors.grey,
                    // ),
                    prefixIcon: Icon(
                      Icons.search,
                      color: Colors.grey,
                    ),
                    fillColor: Colors.white,
                    filled: true,
                    contentPadding: EdgeInsets.fromLTRB(0, 5, 0, 5),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.white, width: 1.0),
                    ),
                  )),
            ),
            SizedBox(width: 10),
            Image.asset('assets/icons/cart-icon.png', width: 30, height: 40, color: Colors.white,),//Icon(Icons.shopping_cart, color: Colors.grey[100], size: 35),
          ],
        ),
      );

  Widget build(BuildContext context) {
    final productData = Provider.of<Products>(context);
    final products = productData.products;

    return Scaffold(
      backgroundColor: Colors.white,
      body: Container(
        margin: EdgeInsets.only(top: 20),
        child: CustomScrollView(
          slivers: [
            SliverList(
                delegate: SliverChildListDelegate([
              _searchBar(),
              SizedBox(height: 15),
              Row(children: [
                SizedBox(width: 15),
                Container(
                  height: 30,
                  color: Colors.grey[100],
                  padding: const EdgeInsets.only(left: 5.0, right: 5.0),
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton<String>(
                        style: TextStyle(color: Colors.black87),
                        hint: Text(
                          _selectedFilter,
                        ),
                        onChanged: (value) {
                          setState(() {
                            _selectedFilter = value;
                          });
                        },
                        items: _filters
                            .map((filter) => DropdownMenuItem<String>(
                                value: filter, child: Text(filter)))
                            .toList()),
                  ),
                )
              ]),

              Padding(
                padding: EdgeInsets.symmetric(horizontal: 15),
                child: Divider(
                  height: 30.0,
                  color: Colors.grey[350],
                ),
              ),
              // Container(
              //   margin: EdgeInsets.only(left:10, bottom: 20),
              //   child: Text(
              //     'Search Results',
              //     style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              //     )
              // ),
              ///FILTER OPTIONS DAYUN DIRI///
            ])),
            SliverGrid(
              delegate: SliverChildBuilderDelegate(
                (BuildContext context, index) => ChangeNotifierProvider.value(
                    value: products[index],
                    child: TrendSearchProductTemplate(
                      imagePath: products[index].imagePath,
                      price: products[index].price,
                      category: products[index].category,
                      productId: products[index].id.toString(),
                      address: 'Carmen',
                      productName: products[index].productName,
                      userLocation: LatLng(8.4676022,124.62209969999999),
                      productLocation: LatLng(8.476629, 124.6390383),
                    )),
                childCount: products.length,
              ),
              gridDelegate:
                  SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2)),
          ],
        ),
      ),
    );
  }
}
