import 'package:flutter/material.dart';
import 'package:sampleflutter/models/cart_model.dart';
import 'package:provider/provider.dart';

class Cart extends StatefulWidget {
  @override
  _CartState createState() => _CartState();
}

class _CartState extends State<Cart> {
  @override
  Widget build(BuildContext context) {
    final cart = Provider.of<Carts>(context);
    return CustomScrollView(
      slivers: [
        SliverPadding(
          padding: const EdgeInsets.all(8.0),
          sliver: SliverFixedExtentList(
            itemExtent: 130.0,
            delegate: SliverChildBuilderDelegate(
              (BuildContext context, int index) {
                return Container(
                  margin: EdgeInsets.only(top: 8),
                  width: double.infinity,
                  height: double.infinity,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(4.0),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey,
                        blurRadius: 2.0,
                        offset: Offset(0, 1),
                      )
                    ],
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Expanded(
                          flex: 2,
                          child: Container(
                            child: Image.asset(cart.products.values
                                    .toList()[index]
                                    .imagePath
                                // CartModel.items[index].imagePath,
                                ),
                          ),
                        ),
                        Expanded(
                          flex: 4,
                          child: Container(
                            padding: EdgeInsets.only(left: 10),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Expanded(
                                  flex: 2,
                                  child: Container(
                                      alignment: Alignment.centerLeft,
                                      child: Text(cart.products.values
                                              .toList()[index]
                                              .productName
                                          // CartModel.items[index].productName,
                                          )),
                                ),
                                Expanded(
                                  flex: 1,
                                  child: Container(
                                      alignment: Alignment.centerLeft,
                                      child: Text(
                                          // CartModel.items[index].category
                                          cart.products.values
                                              .toList()[index]
                                              .category)),
                                ),
                                Expanded(
                                  flex: 2,
                                  child: Container(
                                      alignment: Alignment.centerLeft,
                                      child: Text( cart.products.values
                                              .toList()[index]
                                              .price)),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Expanded(
                          flex: 1,
                          child: Container(
                              child: Align(
                                alignment: Alignment.topRight,
                                child: Icon(Icons.close, size: 15,),
                              )),
                        ),
                      ],
                    ),
                  ),
                );
              },
              childCount: cart.products.length,
            ),
          ),
        ),
      ],
    );
  }
}

// IconButton(
//       icon: Icon(Icons.remove_circle_outline),
//       onPressed: () {
//         Cart.remove(Cart.items[index]);
//       },
//     ),
