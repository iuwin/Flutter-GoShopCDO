import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:provider/provider.dart';
import 'package:sampleflutter/distance_calculator.dart';
import 'package:sampleflutter/models/favorite_model.dart';

class TrendSearchProductTemplate extends StatelessWidget {
  String imagePath;
  String productName;
  String price;
  String address;
  LatLng userLocation, productLocation;
  String category;
  String productId;
  
  TrendSearchProductTemplate({this.imagePath, this.productName, this.price, this.category, this.productId, this.address,
                              this.userLocation, this.productLocation
                            });

  
  @override
  Widget build(BuildContext context) {

    final favorite = Provider.of<Favorites>(context);

    ///Seller and Buyer Distance
    double _sellerBuyerDistance = 0;
    int _distanceKM = 0;
    int _distanceMeter = 0;

    Distance distance = new Distance(userLatitude: userLocation.latitude, userLongitude: userLocation.longitude,
                                    sellerLatitude: productLocation.latitude, sellerLongitude: productLocation.longitude);
    
    _sellerBuyerDistance = distance.getDistanceFromLatLonInKm();
    _distanceKM = _sellerBuyerDistance.toInt();
    _distanceMeter = _distanceKM * 1000;
    print('$_distanceKM KM');
    print('$_distanceMeter M');

    // TODO: implement build
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Stack(
        overflow: Overflow.visible,
        children: [
          Center(
            child: Container(
                width: 150,
                height: 200,
                padding: EdgeInsets.only(bottom: 5),
                decoration: BoxDecoration(
                    color: Colors.white,//Color(0xFFBF2F1F1),
                    borderRadius: BorderRadius.circular(10.0),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey[300],
                        blurRadius: 8,
                        offset: Offset(1, 3),
                      )
                    ]
                    ),
                child: FittedBox(
                  child: GestureDetector(
                    onTap: (){
                      Navigator.pushNamed(
                        context, 
                        '/viewproduct', 
                        arguments: {
                          "imagePath": imagePath,
                          "productName": productName, "productId": productId, "category": category, "price": price    
                      });
                    },
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.end,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Image.asset(imagePath, width: 120, height: 120,),
                        SizedBox(height: 10),
                        Container(
                        width: 150,   
                        padding: EdgeInsets.symmetric(vertical: 5),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(productName, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),),
                                  Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Icon(Icons.star, size: 18, color: Colors.amber),
                                      Text(
                                        '5',
                                        style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 15,
                                        ),
                                      )
                                    ],
                                  ),
                                ],
                              ),
                              SizedBox(height: 5),
                              Text('\$ $price', style: TextStyle(color: Color(0xFFB308278), fontWeight: FontWeight.bold, fontSize: 15)),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Row(
                                    children: [
                                      Icon(Icons.location_on, size: 15, color: Colors.grey,),
                                      Text(
                                        '$address,',
                                          style: TextStyle(
                                          color: Colors.grey[600],
                                          fontSize: 13,
                                        )
                                      )
                                    ],
                                  ),
                                  Text(
                                    '$_distanceKM km away',
                                    style: TextStyle(
                                      color: Colors.grey[600],
                                      fontSize: 13,
                                    )
                                  )
                                ],
                              )
                            ],
                          )
                        )
                      ],
                    ),
                  ),
                ),
              ),
          ),
          Positioned(
            top: 1,
            right: 15,
            child: GestureDetector(
              onTap: () {
                favorite.addFavoriteProduct(
                  productId, imagePath, productName, category, price);
              },
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 5, vertical: 5),
                decoration: BoxDecoration(
                  color: Color(0xFFB308278),
                  borderRadius: BorderRadius.circular(5),
                ),
                child: Icon(Icons.favorite_border, size: 18, color: Colors.white,),
              ),
            )
          ),
        ] 
      ),
    );
  }
}
