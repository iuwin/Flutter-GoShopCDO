import 'package:flutter/material.dart';
import 'package:sampleflutter/models/cart_model.dart';
import 'package:provider/provider.dart';

class Cart extends StatefulWidget {

  @override
  _CartState createState() => _CartState();
}

class _CartState extends State<Cart> {
  double cartTotal = 0, totalTemp = 0;
  bool initializeTotal = true;

  double setPrices(double price, int quantity){
    if(quantity > 1){
      totalTemp = price *= quantity;
      return totalTemp;
    }else{
      return price;
    }
  }

  void initialCartTotal(double price){
    setState(() {
        cartTotal += price;
        print(price);
    });
  }

  @override
  Widget build(BuildContext context) {
    final cart = Provider.of<Carts>(context);

    if (initializeTotal) {
      for (int i = 0; i < cart.products.length; i++){
        initialCartTotal(cart.products.values.toList()[i].price * cart.products.values.toList()[i].quantity);
      }
      initializeTotal = false;
    }

    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: SafeArea(
            child: Container(
              color: Colors.grey[100],
              padding: EdgeInsets.only(top: 20,),
              child: Center(
                child: Text(
                  'My Cart',
                  style: TextStyle(
                    fontSize: 17,
                    color: Colors.grey[500],
                    fontWeight: FontWeight.bold
                  ),
                ),
              ),
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: Container(
                color: Colors.grey[100],
                padding: EdgeInsets.fromLTRB(15, 15, 15, 20),
                child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Subtotal:',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.grey[500]
                        ),
                      ),
                      Text(
                        'Coins:',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.grey[500]
                        ),
                      ),
                    ],
                  ),
                  SizedBox(width: 15,),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '$cartTotal',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.grey[500]
                        ),
                      ),
                      Text(
                        '0.0',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.grey[500]
                        ),
                      ),
                    ],
                  ),
                  SizedBox(width: 25,),
                  GestureDetector(
                    onTap: (){
                      Navigator.pushNamed(context, '/checkout');
                    },
                    child: Container(
                      width: 100,
                      height: 50,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Color(0xFFB308278),
                      ),
                      child: Center(
                        child: Text(
                          'Checkout', 
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold
                          ),
                        )
                      ),
                    ),
                  )
                ]
                ),
              ),
        ),
        SliverPadding(
          padding: const EdgeInsets.all(8.0),
          sliver: SliverFixedExtentList(
            itemExtent: 130.0,
            delegate: SliverChildBuilderDelegate(
              (BuildContext context, int index) {
                return Stack(   
                  overflow: Overflow.visible,
                  children: [
                    Container(
                      margin: EdgeInsets.only(top: 8),
                      width: double.infinity,
                      height: double.infinity,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(4.0),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey,
                            blurRadius: 2.0,
                            offset: Offset(0, 1),
                          )
                        ],
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Expanded(
                              flex: 2,
                              child: Container(
                                child: Image.asset(cart.products.values
                                        .toList()[index]
                                        .imagePath
                                    // CartModel.items[index].imagePath,
                                    ),
                              ),
                            ),
                            Expanded(
                              flex: 3,
                              child: Container(
                                padding: EdgeInsets.only(left: 10),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Expanded(
                                      flex: 2,
                                      child: Container(
                                          alignment: Alignment.centerLeft,
                                          child: Text(cart.products.values
                                                  .toList()[index]
                                                  .productName
                                              // CartModel.items[index].productName,
                                              )),
                                    ),
                                    Expanded(
                                      flex: 1,
                                      child: Container(
                                          alignment: Alignment.centerLeft,
                                          child: Text(
                                              // CartModel.items[index].category
                                              cart.products.values
                                                  .toList()[index]
                                                  .category)),
                                    ),
                                    Expanded(
                                      flex: 2,
                                      child: Container(
                                          alignment: Alignment.centerLeft,
                                          child: Text('${setPrices(cart.products.values.toList()[index].price, cart.products.values.toList()[index].quantity)}'),)
                                          //  Text('${cart.products.values
                                          //         .toList()[index]
                                          //         .price}')),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Expanded(
                              flex: 1,
                              child: Container(
                                  child: Align(
                                    alignment: Alignment.topRight,
                                    child: Icon(Icons.close, size: 15,),
                                  )),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      top: 50,
                      right: 30,
                      child: Text('Quantity: ${cart.products.values.toList()[index].quantity}',)
                    ),
                    Positioned(
                      top: 80,
                      right: 20,
                      child: Container(
                            child:
                                Row(
                                  children: [
                                    Container(
                                      height: 40,
                                      width: 40,
                                      decoration: BoxDecoration(
                                        color: Colors.amber,
                                        borderRadius: BorderRadius.circular(10)
                                      ),
                                      child: IconButton(
                                      onPressed: (){
                                        Future.delayed(Duration.zero, () async {
                                          setState(() {
                                            cart.products.values.toList()[index].quantity += 1;
                                            cartTotal += cart.products.values.toList()[index].price;
                                          });
                                        });
                                      },
                                      icon: Icon(Icons.add),
                                      iconSize: 18,
                                      ),
                                    ),
                                    SizedBox(width: 10,),
                                    GestureDetector(
                                      onTap: (){
                                        Future.delayed(Duration.zero, () async {
                                          setState(() {
                                            if(cart.products.values.toList()[index].quantity > 1){
                                              cart.products.values.toList()[index].quantity -= 1;    
                                              cartTotal -= cart.products.values.toList()[index].price;        
                                            }
                                          });
                                        });
                                      }, 
                                      child: Container(
                                          height: 40,
                                          width: 40,
                                          decoration: BoxDecoration(
                                            color: Colors.amber,
                                            borderRadius: BorderRadius.circular(10)
                                          ),
                                          child: Container(
                                            margin: EdgeInsets.only(bottom: 35),
                                            child: IconButton(
                                              onPressed: (){
                                              },
                                              icon: Icon(Icons.minimize),
                                              iconSize: 18,
                                            ),
                                          ),
                                         
                                        ),
                                    ),
                                  ],
                                )
                          ),
                    )
                  ]
                );
              },
              childCount: cart.products.length,
            ),
          ),
        ),
      ],
    );
  }
}

// IconButton(
//       icon: Icon(Icons.remove_circle_outline),
//       onPressed: () {
//         Cart.remove(Cart.items[index]);
//       },
//     ),
