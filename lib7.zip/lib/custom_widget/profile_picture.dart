import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class ProfilePicture extends StatefulWidget {
  @override
  _ProfilePictureState createState() => _ProfilePictureState();
}

class _ProfilePictureState extends State<ProfilePicture> {
  // PickedFile cameraFile;
  File cameraFile;
  Widget build(BuildContext context) {
    selectFromCamera() async {
      // ignore: deprecated_member_use
      cameraFile = (await ImagePicker.pickImage(
        source: ImageSource.camera,
        maxHeight: 300.0,
        maxWidth: 300.0,
      ));
      setState(() {});
    }

    return Center(
      child: cameraFile == null
          ? CircleAvatar(
              radius: 30.0, //100.0,
              backgroundColor: Colors.grey[300],
              child: ClipOval(
                child: Stack(
                  // overflow: Overflow.clip,
                  children: [
                    Positioned(
                      // top: MediaQuery.of(context).size.height * .15,
                      bottom: 0,
                      right: 0,
                      left: 0,
                      child: GestureDetector(
                        onTap: selectFromCamera,
                        child: Container(
                          height: MediaQuery.of(context).size.height * .05,
                          width: MediaQuery.of(context).size.width * 1,
                          color: Colors.grey[400],
                          child: Icon(
                            Icons.add_a_photo,
                            size: 20.0,
                            color: Color(0xFFB308278),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            )
          : CircleAvatar(
              radius: 30.0,
              backgroundImage: FileImage(cameraFile),
              child: ClipOval(
                child: Stack(
                  // overflow: Overflow.clip,
                  children: [
                    Positioned(
                      // top: MediaQuery.of(context).size.height * .15,
                      bottom: 0,
                      right: 0,
                      left: 0,
                      child: GestureDetector(
                        onTap: selectFromCamera,
                        child: Container(
                          height: MediaQuery.of(context).size.height * .05,
                          width: MediaQuery.of(context).size.width * 1,
                          child: Text(' ')
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
    );
  }
}
