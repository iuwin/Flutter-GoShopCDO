import 'package:flutter/material.dart';
import 'package:sampleflutter/custom_widget/cart.dart';
import 'package:sampleflutter/custom_widget/list_tile_widget.dart';
import 'package:sampleflutter/custom_widget/posted_products.dart';
import 'package:sampleflutter/custom_widget/title_widget.dart';
import 'package:sampleflutter/custom_widget/trend_tab_bar_widget.dart';

class TabBarControllers extends StatelessWidget {
  BuildContext context;
  ScrollController scrollController;
  TabController tabController;
  List<String> tabs;
  String title;
  double cartTotal = 0;

  TabBarControllers(
      {this.context,
      this.scrollController,
      this.tabController,
      this.tabs,
      this.title});

  Widget build(BuildContext context) {
    return NestedScrollView(
      controller: scrollController,
      // ensure that the app bar shows a shadow
      headerSliverBuilder: (BuildContext context, bool innerBoxIsScrolled) {
        // These are the slivers that show up in the "outer" scroll view.
        return <Widget>[
          // create a sliver that absorb the overlap and report to the sliveroverlapabsorvhandle
          SliverSafeArea(
            sliver: SliverAppBar(
              automaticallyImplyLeading: false,
              pinned: false,
              floating: false,
              snap: false,
              // elevation: 0,
              backgroundColor: Colors.white,
              flexibleSpace: FlexibleSpaceBar(
              background: Container(
                margin: EdgeInsets.only(bottom: 20),
                child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Subtotal:',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.grey[500]
                        ),
                      ),
                      Text(
                        'Coins:',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.grey[500]
                        ),
                      ),
                    ],
                  ),
                  SizedBox(width: 15,),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '$cartTotal',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.grey[500]
                        ),
                      ),
                      Text(
                        '0.0',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.grey[500]
                        ),
                      ),
                    ],
                  ),
                  SizedBox(width: 25,),
                  Container(
                    width: 100,
                    height: 50,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Color(0xFFB308278),
                    ),
                    child: Center(
                      child: Text(
                        'Checkout', 
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold
                        ),
                      )
                    ),
                  )
                ]
                ),
              ),
              ),
              expandedHeight: 150.0,
              forceElevated: innerBoxIsScrolled,
              bottom: TrendTabBar(
                  tabs: this.tabs, tabController: this.tabController),
            ),
          ),
        ];
      },
      body: TabBarView(
        children: [
          new Cart(),
        ],
        controller: tabController,
      ),
    );
  }
}
