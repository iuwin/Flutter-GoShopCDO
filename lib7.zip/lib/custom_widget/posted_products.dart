import 'package:flutter/material.dart';

class PostedProduct extends StatefulWidget {
  @override
  _PostedProductState createState() => _PostedProductState();
}

class _PostedProductState extends State<PostedProduct> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(10),
    );
  }
}