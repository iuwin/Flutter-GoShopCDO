import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sampleflutter/models/favorite_model.dart';

class TrendHomeProductTemplate extends StatefulWidget {
  String imagePath;
  String productId;
  String category;
  String productName;
  double price;
  String location;
  double latitude;
  double longitude;

  TrendHomeProductTemplate(
      {this.productId,
      @required this.category,
      @required this.imagePath,
      @required this.productName,
      @required this.price,
      @required this.location,
      @required this.latitude,
      @required this.longitude});

  @override
  _TrendHomeProductTemplateState createState() => _TrendHomeProductTemplateState();
}

class _TrendHomeProductTemplateState extends State<TrendHomeProductTemplate> {

  Icon favIcon = new Icon(Icons.favorite_border,  size: 18, color: Colors.white,);

  @override
  Widget build(BuildContext context) {
    final favorite = Provider.of<Favorites>(context);

    return Padding(
      padding: const EdgeInsets.only(left: 10),
      child: Stack(
        overflow: Overflow.visible,
        children:[ 
          Center(
            child: Container(
                width: 150,
                height: 200,
                margin: EdgeInsets.only(
                  right: 20,
                  bottom: 10,
                ),
                decoration: BoxDecoration(
                    color: Colors.white, //Color(0xFFBF2F1F1),
                    borderRadius: BorderRadius.circular(30.0),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey[300],
                        blurRadius: 8,
                        offset: Offset(1, 3),
                      )
                    ]),
                child: FittedBox(
                    child:GestureDetector(
                      onTap: () {
                        Navigator.pushNamed(context, '/viewproduct',
                          arguments: {"imagePath": widget.imagePath, "productName": widget.productName, "productId": widget.productId,
                           "category": widget.category,"price": widget.price, "location": widget.location,
                           "latitude": widget.latitude, "longitude": widget.longitude});
                      },
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Image.asset(
                            widget.imagePath,
                            width: 120,
                            height: 120,
                          ),
                          SizedBox(height: 10),
                          Container(
                              padding: EdgeInsets.symmetric(vertical: 10),
                              child: Column(
                                children: [
                                  Text(
                                    widget.productName,
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold, fontSize: 15),
                                  ),
                                  SizedBox(height: 20),
                                  //Text('\$ $price', style: TextStyle(color: Color(0xFFB308278), fontWeight: FontWeight.bold, fontSize: 15)),
                                ],
                              )),
                          ],
                        ),
                    ),
                  ),
              ),
          ),
          Positioned(
            top: 0,
            right: 15,
            child: GestureDetector(
              onTap: () {
                favorite.addFavoriteProduct(
                  widget.productId, widget.imagePath, widget.productName, widget.category, widget.price);
                setState(() {
                  favIcon = new Icon(Icons.favorite,  size: 18, color: Colors.grey[100],);
                });
              },
              child: Container(
                  padding: EdgeInsets.symmetric(horizontal: 5, vertical: 5),
                  decoration: BoxDecoration(
                    color: Color(0xFFB308278),
                    borderRadius: BorderRadius.circular(5),
                  ),
                  child: favIcon,
                ),
            ),
          ),
        ]
      ),
    );
  }
}
