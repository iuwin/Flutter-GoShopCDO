import 'package:flutter/material.dart';

class Transaction extends StatefulWidget {
  @override
  _TransactionState createState() => _TransactionState();
}

class _TransactionState extends State<Transaction> {

  Widget purchaseTimeline({Icon icon, String label}) => Column(
    children: [
      icon,
      SizedBox(height: 7),
      Text(label)
    ],
  );

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 25),
      child: Container(
        child: Column(
          children: [
            Container(
              color: Colors.grey[100],
              padding: EdgeInsets.fromLTRB(15, 20, 15, 15),
              child: Column(
                children: [
                  Row(
                    children: [
                      Text(
                        'Purchases',
                        style: TextStyle(
                          fontSize: 16
                        )
                      ),
                    ],
                  ),
                  SizedBox(height: 25),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      purchaseTimeline(
                        icon: Icon(Icons.directions_car),
                        label: 'To Ship'
                      ),
                      SizedBox(width: 35,),
                      purchaseTimeline(
                        icon: Icon(Icons.card_giftcard),
                        label: 'To Receive'
                      ),
                      SizedBox(width: 35,),
                      purchaseTimeline(
                        icon: Icon(Icons.stars),
                        label: 'To Rate'
                      )
                    ]
                  )
                ],
              ),
            )
            



          ],
        ),
      ),
    );
  }
}