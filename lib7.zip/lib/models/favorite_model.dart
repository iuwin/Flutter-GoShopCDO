import 'package:flutter/foundation.dart';

class FavoriteModel {
  final String id;
  final String imagePath;
  final String productName;
  final String category;
  final double price;

  FavoriteModel({
    @required this.id,
    @required this.imagePath,
    @required this.productName,
    @required this.category,
    this.price,
  });
}

class Favorites with ChangeNotifier {
  Map<String, FavoriteModel> _products = {};

  Map<String, FavoriteModel> get products => {..._products};

  int get productCount => _products.length;

  void addFavoriteProduct(String favoriteProductId, String favoriteImagePath,
      String favoriteProductName, String favoriteProductCategory, double favoriteProductPrice) {
    // check if there are existing product in the favorite list update or add new
    if (_products.containsKey(favoriteProductId)) {
      _products.update(
          favoriteProductId,
          (existingFavoriteProduct) => FavoriteModel(
              id: DateTime.now().toString(),
              imagePath: existingFavoriteProduct.imagePath,
              productName: existingFavoriteProduct.productName,
              category: existingFavoriteProduct.category,
              price: existingFavoriteProduct.price));
    } else {
      _products.putIfAbsent(
          favoriteProductId,
          () => FavoriteModel(
              id: DateTime.now().toString(),
              imagePath: favoriteImagePath,
              productName: favoriteProductName,
              category: favoriteProductCategory,
              price: favoriteProductPrice));
    }
    notifyListeners();
  }

  void removeProduct(String id) {
    _products.remove(id);
    notifyListeners();
  }

  // void removeSingleProduct(String id) {
  //   if (_products.containsKey(id)) {
  //     return;
  //   }
  //   if (_products[id].quanity > 1) {
  //     _products.update(id, (existingFavoriteProduct) => FavoriteModel(
  //             id: DateTime.now().toString(),
  //             imagePath: existingFavoriteProduct.imagePath,
  //             quantity: existingFavoriteProduct.quantity - 1,
  //             productName: existingFavoriteProduct.productName,
  //             category: existingFavoriteProduct.category));
  //   }
  // notifyListeners();
  // }

  void clear() {
    _products = {};
    notifyListeners();
  }
}
