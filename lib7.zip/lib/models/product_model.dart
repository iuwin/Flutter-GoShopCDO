import 'package:flutter/foundation.dart';

class ProductModel with ChangeNotifier {
  final int id;
  final String imagePath;
  final String productName;
  final String category;
  final double price;
  final String description;
  final String location;
  final double latitude;
  final double longitude;
  // final price;

  ProductModel({
    @required this.id,
    @required this.imagePath,
    @required this.productName,
    @required this.category,
    this.price,
    this.description,
    this.location,
    this.latitude,
    this.longitude
    // @required this.price,
  });
}

class Products with ChangeNotifier {
  List<ProductModel> _products = [
    //Clothing
    ProductModel(
        id: 1,
        price: 200,
        imagePath: 'assets/products/clothing/girl_jacket.png',
        productName: 'Women\'s Jacket',
        category: 'Clothing',
        location: 'Nazareth',
        latitude: 8.4708,
        longitude: 124.6483
        ),
    ProductModel(
        id: 2,
        price: 100,
        imagePath: 'assets/products/clothing/cap.png',
        productName: 'Nike Cap',
        category: 'Clothing',
        location: 'Lapasan',
        latitude: 8.4835,
        longitude: 124.6616
        ),
    ProductModel(
        id: 3,
        price: 250,
        imagePath: 'assets/products/clothing/boy_jacket.png',
        productName: 'Men\'s Jacket',
        category: 'Clothing',
        location: 'Patag',
        latitude: 8.4886,
        longitude: 124.6220
        ),
    ProductModel(
        id: 4,
        price: 530,
        imagePath: 'assets/products/clothing/jeans.png',
        productName: 'Jeans',
        category: 'Clothing',
        location: 'Macabalan',
        latitude: 8.4997,
        longitude: 124.6621
        ),
    ProductModel(
        id: 5,
        price: 980,
        imagePath: 'assets/products/clothing/jordan_shoes.png',
        productName: 'Jordan Shoes',
        category: 'Clothing',
        location: 'Gusa',
        latitude: 8.4742,
        longitude: 124.6821
        ),

    //Gadgets
    ProductModel(
        id: 6,
        price: 11000,
        imagePath: 'assets/products/gadgets/laptop.png',
        productName: 'HP Laptop',
        category: 'Gadgets',
        location: 'Carmen',
        latitude: 8.476629,
        longitude: 124.6390383
        ),
    ProductModel(
        id: 7,
        price: 600,
        imagePath: 'assets/products/gadgets/mouse.png',
        productName: 'Wired Mouse',
        category: 'Gadgets',
        location: 'Gusa',
        latitude: 8.4742,
        longitude: 124.6821
        ),
    ProductModel(
        id: 8,
        price: 500,
        imagePath: 'assets/products/gadgets/keyboard.png',
        productName: 'Keyboard',
        category: 'Gadgets',
        location: 'Carmen',
        latitude: 8.476629,
        longitude: 124.6390383
        ),
    ProductModel(
        id: 9,
        price: 700,
        imagePath: 'assets/products/gadgets/flashdrive.png',
        productName: 'Flashdrive',
        category: 'Gadgets',
        location: 'Gusa',
        latitude: 8.4742,
        longitude: 124.6821
        ),
    ProductModel(
        id: 10,
        price: 1200,
        imagePath: 'assets/products/gadgets/wireless_camera.png',
        productName: 'Wireless Camera',
        category: 'Gadgets',
        location: 'Lapasan',
        latitude: 8.4835,
        longitude: 124.6616
        ),

    //Furnitures
    ProductModel(
        id: 11,
        price: 3000,
        imagePath: 'assets/products/furniture/sofa.png',
        productName: 'Sofa',
        category: 'Furniture',
        location: 'Nazareth',
        latitude: 8.4708,
        longitude: 124.6483
        ),
    ProductModel(
        id: 12,
        price: 1110,
        imagePath: 'assets/products/furniture/chair.png',
        productName: 'Wooden Chair',
        category: 'Furniture',
        location: 'Patag',
        latitude: 8.4886,
        longitude: 124.6220
        ),
    ProductModel(
        id: 13,
        price: 2600,
        imagePath: 'assets/products/furniture/bed.png',
        productName: 'Bed',
        category: 'Furniture',
        location: 'Carmen',
        latitude: 8.476629,
        longitude: 124.6390383
        ),
    ProductModel(
        id: 14,
        price: 1500,
        imagePath: 'assets/products/furniture/table.png',
        productName: 'Table',
        category: 'Furniture',
        location: 'Macabalan',
        latitude: 8.4997,
        longitude: 124.6621
        ),
    ProductModel(
        id: 15,
        price: 800,
        imagePath: 'assets/products/furniture/umbrella_holder.png',
        productName: 'Umbrella Holder',
        category: 'Furniture',
        location: 'Patag',
        latitude: 8.4886,
        longitude: 124.6220
        ),

    //Toys
    ProductModel(
        id: 16,
        price: 200,
        imagePath: 'assets/products/toys/stuff_toy.png',
        productName: 'Stuff Toy',
        category: 'Toy',
        location: 'Macabalan',
        latitude: 8.4997,
        longitude: 124.6621
        ),
    ProductModel(
        id: 17,
        price: 900,
        imagePath: 'assets/products/toys/doll_house.png',
        productName: 'Doll House',
        category: 'Toy',
        location: 'Carmen',
        latitude: 8.476629,
        longitude: 124.6390383
        ),
    ProductModel(
        id: 18,
        price: 150,
        imagePath: 'assets/products/toys/cow_piano.png',
        productName: 'Cow Piano',
        category: 'Toy',
        location: 'Nazareth',
        latitude: 8.4708,
        longitude: 124.6483
        ),
    ProductModel(
        id: 19,
        price: 400,
        imagePath: 'assets/products/toys/robot.png',
        productName: 'Robot',
        category: 'Toy',
        location: 'Lapasan',
        latitude: 8.4835,
        longitude: 124.6616
        ),
    ProductModel(
        id: 20,
        price: 150,
        imagePath: 'assets/products/toys/Toy_gun.png',
        productName: 'Toy Gun',
        category: 'Toy',
        location: 'Gusa',
        latitude: 8.4742,
        longitude: 124.6821
        ),


    //Hardware

    ProductModel(
        id: 21,
        price: 500,
        imagePath: 'assets/products/hardware/hammer.png',
        productName: 'Hammer',
        category: 'Hardware',
        location: 'Nazareth',
        latitude: 8.4708,
        longitude: 124.6483
        ),
    ProductModel(
        id: 22,
        price: 300,
        imagePath: 'assets/products/hardware/tool_case.png',
        productName: 'Tool Case',
        category: 'Hardware',
        location: 'Macabalan',
        latitude: 8.4997,
        longitude: 124.6621
        ),
    ProductModel(
        id: 23,
        price: 230,
        imagePath: 'assets/products/hardware/doorknob.png',
        productName: 'Door knob',
        category: 'Hardware',
        location: 'Gusa',
        latitude: 8.4742,
        longitude: 124.6821
        ),
    ProductModel(
        id: 24,
        price: 450,
        imagePath: 'assets/products/hardware/plier.png',
        productName: 'Lineman\'s Plier',
        category: 'Hardware',
        location: 'Carmen',
        latitude: 8.476629,
        longitude: 124.6390383
        ),
  ];

  List<ProductModel> get products => [..._products];
}
