import 'dart:collection';
import 'package:flutter/material.dart';
import 'package:fa_stepper/fa_stepper.dart';
import 'product_description.dart';
import 'product_pricing.dart';
import 'product_upload.dart';

class Post extends StatefulWidget {
  _Post createState() => _Post();
}

class _Post extends State<Post> {
  int currentStep = 0;
  bool uploadingStep = false;

  dynamic onSubmitProduct() {}

  // List<Widget> controlButtons(Function onCancel, Function onContinue, Function onSubmitProduct){
  //   if(uploadingStep == false){
  //     return <Widget>[
  //       FlatButton(
  //         onPressed: onCancel,
  //         child: Icon(Icons.keyboard_arrow_left),
  //       ),
  //       FlatButton(
  //         onPressed: onContinue,
  //         child: Icon(Icons.keyboard_arrow_right),
  //       ),
  //     ];
  //   }else if(uploadingStep == true){
  //     return <Widget>[
  //       GestureDetector(
  //         child: Container(
  //           color: Colors.green,
  //           child: Text(
  //             'Post Product'
  //           ),
  //         ),
  //       )
  //     ];
  //   }

  // }

  @override
  Widget build(BuildContext context) {
    var mapData = HashMap<String, String>();
    mapData["productPhotoConvertedToString"] = ProductDescriptionState.img64;
    mapData["productName"] = ProductDescriptionState.productNameController.text;
    mapData["category"] = ProductDescriptionState.selectedCategory;
    mapData["description"] = ProductDescriptionState.descriptionController.text;
    mapData["condition"] = ProductDescriptionState.selectedCondition;
    mapData["address"] = ProductDescriptionState.addressController.text;
    mapData["fixedPrice"] = ProductPricingState.fixedPriceController.text;
    mapData["bargainPrice"] = ProductPricingState.bargainPriceController.text;
    mapData["quantity"] = ProductPricingState.quantityController.text;

    return Scaffold(
      body: SafeArea(
        child: Container(
          // padding: EdgeInsets.only(left: 15, right: 15),
          child: FAStepper(
              physics: ClampingScrollPhysics(),
              steps: [
                FAStep(
                  isActive: (currentStep >= 1) ? true : false,
                  state: currentStep == 0
                      ? FAStepstate.editing
                      : currentStep > 0
                          ? FAStepstate.complete
                          : FAStepstate.indexed,
                  content: ProductDescription(),
                  title: Padding(
                    padding: const EdgeInsets.only(left: 15, right: 15),
                    child: Text(
                      'Product Information',
                      style: TextStyle(
                        color: currentStep == 0
                            ? Color(0xFFB296961)
                            : currentStep > 0
                                ? Color(0xFFB296961)
                                : Colors.grey.shade400,
                      ),
                    ),
                  ),
                ),
                FAStep(
                  isActive: (currentStep >= 2) ? true : false,
                  state: currentStep == 1
                      ? FAStepstate.editing
                      : currentStep > 1
                          ? FAStepstate.complete
                          : FAStepstate.indexed,
                  title: Padding(
                    padding: const EdgeInsets.only(left: 15, right: 15),
                    child: Text(
                      'Product Pricing',
                      style: TextStyle(
                        color: currentStep == 1
                            ? Color(0xFFB296961)
                            : currentStep > 1
                                ? Color(0xFFB296961)
                                : Colors.grey.shade400,
                      ),
                    ),
                  ),
                  content: ProductPricing(),
                ),
                FAStep(
                  state: currentStep == 2
                      ? FAStepstate.editing
                      : currentStep > 2
                          ? FAStepstate.complete
                          : FAStepstate.indexed,
                  title: Padding(
                    padding: const EdgeInsets.only(left: 15, right: 15),
                    child: Text(
                      'Upload',
                      style: TextStyle(
                        color: currentStep == 2
                            ? Color(0xFFB296961)
                            : currentStep > 2
                                ? Color(0xFFB296961)
                                : Colors.grey.shade400,
                      ),
                    ),
                  ),
                  isActive: (currentStep >= 3) ? true : false,
                  // subtitle: const Text("Error!"),
                  content: ProductUpload(mapInfo: mapData),
                ),
              ],
              currentStep: currentStep,
              onStepContinue: () {
                setState(() {
                  if (currentStep < 3) {
                    if (currentStep == 0 &&
                        ProductDescriptionState.formKey.currentState
                            .validate()) {
                      currentStep = currentStep + 1;
                      uploadingStep = false;
                    } else if (currentStep == 1 &&
                        ProductPricingState.formKey.currentState.validate()) {
                      currentStep = currentStep + 1;
                      uploadingStep = false;
                    }
                  } else {
                    uploadingStep = true;
                    // currentStep = 0;
                  }
                });
              },
              onStepCancel: () {
                setState(() {
                  if (currentStep > 0) {
                    currentStep = currentStep - 1;
                  } else {
                    currentStep = 0;
                  }
                });
              },
              type: FAStepperType.horizontal,
              //button edit
              controlsBuilder: (BuildContext context,
                  {VoidCallback onStepContinue, VoidCallback onStepCancel}) {
                return Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    FlatButton(
                      onPressed: onStepCancel,
                      child: Icon(Icons.keyboard_arrow_left),
                    ),
                    FlatButton(
                      onPressed: onStepContinue,
                      child: Icon(Icons.keyboard_arrow_right),
                    ),
                  ],
                );
              }),
        ),
      ),
    );
  }
}
