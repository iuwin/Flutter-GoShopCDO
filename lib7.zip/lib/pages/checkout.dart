import 'package:flutter/material.dart';

class Checkout extends StatefulWidget {
  @override
  _CheckoutState createState() => _CheckoutState();
}

class _CheckoutState extends State<Checkout> {

  Text customText(String text, Color color, double fontSize) => Text(
    text,
    style: TextStyle(
      color: color,
      fontSize: fontSize
    ),
  );


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        //backgroundColor: Colors.white,
        elevation: 0,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Container(
            child: Column(
              children: [
                Container(
                  color: Colors.white,
                  padding: EdgeInsets.symmetric(horizontal: 15, vertical: 20),
                  child: Column(
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Icon(Icons.location_on, color: Color(0xFFB308278), size: 20,),
                          customText('Address', Colors.grey[700], 16)
                        ],
                      ),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(width: 20,),
                          customText('Pepeng Kaliwete', Colors.grey[700], 13),
                        ],
                      ),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(width: 20,),
                          customText('09568745327', Colors.grey[700], 13),
                        ],
                      ),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(width: 20,),
                          customText('022 Carmen, Cagayan de Oro City', Colors.grey[700], 13),
                        ],
                      ),
                    ],
                  ),
                ),
                Container(
                  color: Colors.white,
                  margin: EdgeInsetsDirectional.only(top: 15),
                  padding: EdgeInsets.symmetric(horizontal: 15, vertical: 20),
                  child: Column(
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Icon(Icons.shopping_basket, color: Color(0xFFB308278), size: 20,),
                          SizedBox(width: 5,),
                          customText('Shopping', Colors.grey[700], 16)
                        ],
                      ),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(width: 20),
                          Column(
                            children: [
                              SizedBox(height: 15),
                              customText('Total Items', Colors.grey[700], 14),
                              SizedBox(height: 10),
                              Container(
                                padding: EdgeInsets.symmetric(horizontal: 40, vertical: 20),
                                decoration: BoxDecoration(
                                  color: Color(0xFFB308278),
                                  borderRadius: BorderRadius.circular(15),
                                ),
                                child: customText('9', Colors.white, 18),
                              ),
                            ],
                          ),
                          Column(
                            children: [

                            ],
                          )
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        )
      ),
    );
  }
}